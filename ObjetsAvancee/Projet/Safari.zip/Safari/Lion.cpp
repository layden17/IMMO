#include "Lion.hpp"

Lion::Lion(int playerID, int pieceID)
    : Piece('L', playerID, pieceID) {}

// ... (ajoutez d'autres membres spécifiques si nécessaire)
