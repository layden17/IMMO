#ifndef LION_HPP
#define LION_HPP

#include "Piece.hpp"

class Lion : public Piece {
public:
    Lion(int playerID, int pieceID);


    // ... (ajoutez d'autres membres spécifiques si nécessaire)
};

#endif // LION_HPP
