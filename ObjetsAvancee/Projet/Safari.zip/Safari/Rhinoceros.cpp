#include "Rhinoceros.hpp"

Rhinoceros::Rhinoceros(int playerID, int pieceID)
    : Piece('R', playerID, pieceID) {}


// ... (ajoutez d'autres membres spécifiques si nécessaire)
