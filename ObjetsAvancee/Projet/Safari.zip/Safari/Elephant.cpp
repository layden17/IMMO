#include "Elephant.hpp"

Elephant::Elephant(int playerID, int pieceID)
    : Piece('E', playerID, pieceID) {}

// ... (ajoutez d'autres membres spécifiques si nécessaire)
